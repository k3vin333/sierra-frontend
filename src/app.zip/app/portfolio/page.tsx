'use client'

import React, { useEffect, useState } from 'react'
import { useAuth } from '@/context/useAuth'
import Layout from '../layout'
import {
    Typography,
    CircularProgress,
    Box,
    Paper,
    Tabs,
    Tab
} from '@mui/material'

import ESGTrendChart from '../report/[companyId]/components/ESGTrendChart'
import ESGFactorsChart from '../report/[companyId]/components/ESGFactorsChart'
import ESGLevelChart from '../report/[companyId]/components/ESGLevelChart'
import FinanceImpactChart from '../report/[companyId]/components/FinanceImpactChart'
import ESGPrediction from '../report/[companyId]/components/ESGPrediction'

export default function PortfolioPage() {
    const { getTickers } = useAuth()
    const [tickers, setTickers] = useState<string[]>([])
    const [loading, setLoading] = useState(true)
    const [tabIndices, setTabIndices] = useState<{ [ticker: string]: number }>({})

    useEffect(() => {
        const loadTickers = async () => {
            const data = await getTickers()
            const tickerList = data.map((d) => d.ticker)
            setTickers(tickerList)
            const initialTabs: { [key: string]: number } = {}
            tickerList.forEach((ticker) => (initialTabs[ticker] = 0))
            setTabIndices(initialTabs)
            setLoading(false)
        }

        loadTickers()
    }, [])

    const handleTabChange = (ticker: string, newValue: number) => {
        setTabIndices((prev) => ({ ...prev, [ticker]: newValue }))
    }

    if (loading) return <Layout><CircularProgress /></Layout>

    return (
        <Layout>
            <Box sx={{ p: 4 }}>
                <Typography variant="h4" gutterBottom>My Portfolio</Typography>

                {tickers.length === 0 && <Typography>No tickers followed yet.</Typography>}

                {tickers.map((ticker) => (
                    <Paper key={ticker} elevation={3} sx={{ p: 3, mb: 4 }}>
                        <Typography variant="h5" gutterBottom>{ticker}</Typography>
                        <ESGPrediction companyId={ticker} />

                        <Tabs
                            value={tabIndices[ticker] || 0}
                            onChange={(_, newValue) => handleTabChange(ticker, newValue)}
                            sx={{ mb: 2 }}
                        >
                            <Tab label="Total ESG Risk Trend" />
                            <Tab label="ESG Factors" />
                            <Tab label="ESG Level" />
                            <Tab label="Finance Impact" />
                        </Tabs>

                        {tabIndices[ticker] === 0 && <ESGTrendChart companyId={ticker} />}
                        {tabIndices[ticker] === 1 && <ESGFactorsChart companyId={ticker} />}
                        {tabIndices[ticker] === 2 && <ESGLevelChart companyId={ticker} />}
                        {tabIndices[ticker] === 3 && <FinanceImpactChart companyId={ticker} />}
                    </Paper>
                ))}
            </Box>
        </Layout>
    )
}
